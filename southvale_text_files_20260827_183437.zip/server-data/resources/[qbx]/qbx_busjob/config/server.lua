return {
    bonusChance = 36,
}